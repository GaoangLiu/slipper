A package for faster Python programming. 

## Usage
```python
from slipper import slipper as ss

js = ss.jsonread('ajsonfile.json')
ss.pp(js) # == pprint.pprint(js)
```

## Install
python3 -m pip install -i https://test.pypi.org/simple/ slipper==0.0.3
