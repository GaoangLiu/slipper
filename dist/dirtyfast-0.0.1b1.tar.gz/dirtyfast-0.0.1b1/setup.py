import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="dirtyfast",
    version="0.0.1b1",
    author="Gaogle",
    author_email="byteleap@gmail.com",
    description="A package for dirty faster Python programming",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/GaoangLiu/slipper",
    package_dir={'': 'src'},
    py_modules=['dirtyfast', 'logger'],
    # packages=setuptools.find_packages(),
    install_requires=['colorlog>=4.6.1', 'tqdm>=4.56.0'],
    entry_points={
        'console_scripts': ['sli=dirtyfast:main'],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
